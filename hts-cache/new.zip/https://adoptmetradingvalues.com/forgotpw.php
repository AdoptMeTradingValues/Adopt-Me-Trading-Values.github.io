<html>
<head>
<script data-ad-client="ca-pub-5814941088162332" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<link rel="icon" type="image/png" href="favicon.png" />
<title>Roblox Adopt Me Trading Values - Register/Profile</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<style>
.tradezoneupdates {
  background-color: #CDFFE6;
  border-radius: 25px;
  margin:2% 8% 2% 8%;
  text-align:left;
}
.outergridupdates {
  display: grid;
  grid-template-columns: 100%;
  background-color: #CDFFE6;
  padding: 10px;
  border-radius: 25px;
  max-width:80%;
  margin: 0 auto;
}
.register {
	box-sizing: border-box;
  	font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
  	font-size: 16px;
  	-webkit-font-smoothing: antialiased;
  	-moz-osx-font-smoothing: grayscale;
  	width: 400px;
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
  	margin: 20px auto;
}
.register h1 {
  	text-align: center;
  	color: #5b6574;
  	font-size: 24px;
  	padding: 20px 0 20px 0;
  	border-bottom: 1px solid #23b574;
}
.register form {
  	display: flex;
  	flex-wrap: wrap;
  	justify-content: center;
  	padding-top: 20px;
}
.register form label {
  	display: flex;
  	justify-content: center;
  	align-items: center;
  	width: 50px;
 	height: 50px;
  	background-color: #23b574;
  	color: #ffffff;
}
.register form input[type="password"], .register form input[type="text"], .register form input[type="email"] {
  	width: 310px;
  	height: 50px;
  	border: 1px solid #23b574;
  	margin-bottom: 20px;
  	padding: 0 15px;
}
.register form input[type="submit"] {
  	width: 100%;
  	padding: 15px;
  	margin-top: 20px;
  	background-color: #23b574;
 	border: 0;
  	cursor: pointer;
  	font-weight: bold;
  	color: #ffffff;
  	transition: background-color 0.2s;
}
.register form input[type="submit"]:hover {
	background-color: #6633cc;
  	transition: background-color 0.2s;
}
</style>
</head>
<body bgcolor="#bbddff">
<br>
<div align="center"><img src="images/header.png" alt="Roblox Adopt Me Trading Values">
<ul align="center">
<li><a href="index.php">W/F/L</a></li>
<li><a href="pet-value-list.php">Pet Value List</a></li>
<li><a href="play-games.php">Games</a></li>
<li><a href="videos.php">Videos</a></li>
<li><a href="tips-to-get-rich.php">Tips</a></li>
<li><a href="roblox-adopt-me.php">About</a></li>
</ul>
</div>
<div class="tradezoneupdates">
<div class="outergridupdates">
<div id="google_translate_element" style="text-align:right; display:inline;">
<script type="text/javascript">function googleTranslateElementInit() {  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, gaTrack: true, gaId: 'UA-3744414-1'}, 'google_translate_element');} </script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script></div>
<div style="font-size:20px; font-weight:bold;">
<u>Forgot your password?</u><br><br>Enter your username in the form below. If you had provided a valid email address during the Sign Up process, then you will be emailed directions for resetting your password.<br><br>
<div class="register">
<form action="forgotpw.php" method="post" autocomplete="off">
<label for="username">
<img src="username.png" alt="UN" style="height:30px; width:30px;">
</label>
<input type="text" name="username" placeholder="Username" id="username" maxlength="30" required>
<input type="submit" value="E-mail Me to Reset My Password">
</form>
</div>
</div>
<br><br><br>
</div>
</div>
<div align="center">

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5814941088162332" crossorigin="anonymous"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5814941088162332" data-ad-slot="7684926393" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<br><br>
<div align="center"><i>Last updated July 7, 2022</i> - <a href="updates.php">View Update Log</a> | <a href="privacypolicy.php">Privacy Policy</a></div><br><br>

<script async src="https://www.googletagmanager.com/gtag/js?id=G-40249HE5LR"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-40249HE5LR');
</script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-60ba7e2fc1d62d27"></script>
</body>
</html>

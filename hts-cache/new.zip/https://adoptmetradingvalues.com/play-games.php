<html>
<head>
<script data-ad-client="ca-pub-5814941088162332" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<link rel="icon" type="image/png" href="favicon.png" />
<title>Roblox Adopt Me Trading Values - Play Games Free Online</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<style>
.tradezoneupdates {
  background-color: #CDFFE6;
  border-radius: 25px;
  margin:2% 8% 2% 8%;
  text-align:left;
}
.outergridupdates {
  display: grid;
  grid-template-columns: 100%;
  background-color: #CDFFE6;
  padding: 10px;
  border-radius: 25px;
  max-width:80%;
  margin: 0 auto;
}

.flier {
	pointer-events: auto; 
}

.flier > * {
/* Adjust animation duration to change the element’s speed */
        animation: fly 30s linear infinite;
        /*pointer-events: none !important;*/
	top: 0;
	left: 0;
	transform: translateX(-120%) translateY(-120%) rotateZ(0);
	position: fixed;
	animation-delay: 6s;
	z-index: 999999;
}

 /* Keyframe values control where the element will begin
    and end its trajectory across the screen. Each rule
    represents a path the element follows across the screen. */


@keyframes fly {

	98.001%, 0% {
                display: block;
		transform: translateX(-200%) translateY(100vh) rotateZ(0deg) rotateY(-180deg)
	}

	15% {
		transform: translateX(100vw) translateY(-100%) rotateZ(20deg) rotateY(180deg)
	}

	15.001%, 18% {
		transform: translateX(100vw) translateY(-30%) rotateZ(0deg) rotateY(180deg)
	}

	40% {
		transform: translateX(-200%) translateY(3vh) rotateZ(-20deg) rotateY(-180deg)
	}

	40.001%, 43% {
		transform: translateX(-200%) translateY(-100%) rotateZ(-20deg) rotateY(-180deg)
	}

	65% {
		transform: translateX(100vw) translateY(50vh) rotateZ(0deg) rotateY(180deg)
	}

	65.001%, 68% {
		transform: translateX(20vw) translateY(-200%) rotateZ(20deg) rotateY(180deg)
	}

	95% {
		transform: translateX(10vw) translateY(100vh) rotateZ(0deg) rotateY(180deg)
	}
}
</style>
</head>
<body bgcolor="#bbddff">
<style>
.login {
	box-sizing: border-box;
  	font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
  	font-size: 16px;
  	-webkit-font-smoothing: antialiased;
  	-moz-osx-font-smoothing: grayscale;
  	width: 400px;
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
  	margin: 300px auto;
}
.login h1 {
  	text-align: center;
  	color: #5b6574;
  	font-size: 24px;
  	padding: 20px 0 20px 0;
  	border-bottom: 2px solid #23b574;
}
.login form {
  	display: flex;
  	flex-wrap: wrap;
  	justify-content: center;
  	padding-top: 20px;
}
.login form label {
  	display: flex;
  	justify-content: center;
  	align-items: center;
  	width: 50px;
  	height: 50px;
  	background-color: #23b574;
  	color: #ffffff;
}
.login form input[type="password"], .login form input[type="text"] {
  	width: 310px;
  	height: 50px;
  	border: 1px solid #dee0e4;
  	margin-bottom: 20px;
  	padding: 0 15px;
}
.login form input[type="submit"] {
  	width: 100%;
  	padding: 15px;
 	margin-top: 20px;
  	background-color: #23b574;
  	border: 0;
  	cursor: pointer;
  	font-weight: bold;
  	color: #ffffff;
  	transition: background-color 0.2s;
}
.login form input[type="submit"]:hover {
	background-color: #6633cc;
  	transition: background-color 0.2s;
}
</style>
<div align="right" style="font-size:24px;"> <a class="wflbutton" style="font-size:22px; margin-right:10px; background-color:#6633cc; min-width:50px;" href="#" onClick="document.getElementById('modalboomlogin').style.visibility='visible'; return false;">Log In</a> <a class="wflbutton" style="font-size:22px; margin-right:25px; background-color:#6633cc; min-width:50px;" href="register.php">Sign Up</a> <a href="#"><img src="images/help.png" alt="?" title="Help" style="margin-right:3px; width:30px; vertical-align:middle; height:30px;" onClick="document.getElementById('videohelp2').style.visibility='visible'; return false;"></a>
</div>
<div id="videohelp2" style="position:fixed; visibility:hidden; padding:2% 5% 5% 5%; z-index: 8; background-color:#CDFFE6; min-width:50%; min-height:50%; top:25%; left:25%; margin-left:-5%; margin-top:-10% display: inline-block; cursor: pointer; border:1px solid black; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; overflow: auto;	border-radius: 25px; text-align:center;">
<div class="popupgridcloser"><span onClick="document.getElementById('videohelp2').style.visibility='hidden'; document.getElementById('bighelpvid2').src='https://www.youtube.com/embed/dq1N_-GQtEc';" style="font-size:20px; color:#ffffff; background-color:#ee2222; padding:4px; font-weight:bold;"> X </span><br></div>
<span style="text-align:center;">Find Fair Trades Quickly<br>
AdoptMeTradingValues.com How-To Video<br><br></span>
<iframe id="bighelpvid2" width="640" height="390" src="https://www.youtube.com/embed/dq1N_-GQtEc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
<div class="modal" id="modalboomlogin"><div class="login" id="loginscreen">
<div class="popupgridcloser" style="background-color:unset;"><span style="padding-right:45%; font-size:26px;">Log In</span> <span onClick="document.getElementById('modalboomlogin').style.visibility='hidden';" style="font-size:20px; color:#ffffff; background-color:#ee2222; padding:4px; font-weight:bold;"> X </span></div>
<form action="home.php" method="post">
<label for="username">
<img src="username.png" alt="UN" style="height:30px; width:30px;">
</label>
<input type="text" name="username" placeholder="Username" id="username" required>
<label for="password">
<img src="password.png" alt="PW" style="height:30px; width:30px;">
</label>
<input type="password" name="password" placeholder="Password" id="password" required>
<br><span align="center" style="font-size:small;"><a href="forgotpw.php">Forgot Password</a></span><br>
<input type="submit" value="Login">
</form>
</div></div><div align="center"><img src="images/header.png" alt="Roblox Adopt Me Trading Values">
<ul align="center">
<li><a href="index.php">W/F/L</a></li>
<li><a href="pet-value-list.php">Pet Value List</a></li>
<li><a href="play-games.php">Games</a></li>
<li><a href="videos.php">Videos</a></li>
<li><a href="tips-to-get-rich.php">Tips</a></li>
<li><a href="roblox-adopt-me.php">About</a></li>
</ul>
</div>
<div class="tradezoneupdates">
<div class="outergridupdates">
<div id="google_translate_element" style="text-align:right; display:inline;">
<script type="text/javascript">function googleTranslateElementInit() {  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, gaTrack: true, gaId: 'UA-3744414-1'}, 'google_translate_element');} </script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script></div>
<div style="font-size:36px; font-weight:bold;" align="center"><u>Games</u><br><br>
<table width="90%">
<tr>
<td width="50%"><div align="center"><a href="know-your-values-game.php"><img src="knowyourvalues.png" alt="Know Your Values Game" style="max-width:100%;"><br>Know Your Values Game</a></div></td>
<td width="50%"><div align="center"><a href="know-your-facts-game.php"><img src="knowyourfacts.png" alt="Know Your Facts Game" style="max-width:100%;"><br>Know Your Facts Game</a></div></td>
</tr>
</table><br>
<style>
.mf_responsive_1 { width: 300px; height: 250px; }
@media(min-width: 500px) { .mf_responsive_1 { width: 300px; height: 250px; } }
@media(min-width: 800px) { .mf_responsive_1 { width: 300px; height: 250px; } }
</style>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5814941088162332" crossorigin="anonymous"></script>

<ins class="adsbygoogle mf_responsive_1" style="display:inline-block;min-width:400px;max-width:970px;width:100%;" data-full-width-responsive="true" data-ad-client="ca-pub-5814941088162332" data-ad-slot="1545665476"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
<br><br><br>
</div>
</div>
<div class="flier"><img id="bbb" src="images/6.png" alt="Ahhh! Flying Pet!" title="Ahhh! Flying Pet!"></div>
<br>
<script>
var audio1 = new Audio("laugh.mp3");
function playAudio() {
  audio1.currentTime = 0; audio1.play();
}

document.getElementById("bbb").addEventListener("click", function() {
  playAudio();
});
</script>
<div align="center">

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5814941088162332" crossorigin="anonymous"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5814941088162332" data-ad-slot="7684926393" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<br><br>
<div align="center"><i>Last updated July 7, 2022</i> - <a href="updates.php">View Update Log</a> | <a href="privacypolicy.php">Privacy Policy</a></div><br><br>

<script async src="https://www.googletagmanager.com/gtag/js?id=G-40249HE5LR"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-40249HE5LR');
</script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-60ba7e2fc1d62d27"></script>
</body>
</html>

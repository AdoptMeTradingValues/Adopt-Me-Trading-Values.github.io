<html>
<head>
<script data-ad-client="ca-pub-5814941088162332" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<link rel="icon" type="image/png" href="favicon.png" />
<title>Roblox Adopt Me Trading Values - Register/Profile</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<style>
.tradezoneupdates {
  background-color: #CDFFE6;
  border-radius: 25px;
  margin:2% 8% 2% 8%;
  text-align:left;
}
.outergridupdates {
  display: grid;
  grid-template-columns: 100%;
  background-color: #CDFFE6;
  padding: 10px;
  border-radius: 25px;
  max-width:80%;
  margin: 0 auto;
}
.register {
	box-sizing: border-box;
  	font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
  	font-size: 16px;
  	-webkit-font-smoothing: antialiased;
  	-moz-osx-font-smoothing: grayscale;
  	width: 400px;
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
  	margin: 20px auto;
}
.register h1 {
  	text-align: center;
  	color: #5b6574;
  	font-size: 24px;
  	padding: 20px 0 20px 0;
  	border-bottom: 1px solid #23b574;
}
.register form {
  	display: flex;
  	flex-wrap: wrap;
  	justify-content: center;
  	padding-top: 20px;
}
.register form label {
  	display: flex;
  	justify-content: center;
  	align-items: center;
  	width: 50px;
 	height: 50px;
  	background-color: #23b574;
  	color: #ffffff;
}
.register form input[type="password"], .register form input[type="text"], .register form input[type="email"] {
  	width: 310px;
  	height: 50px;
  	border: 1px solid #23b574;
  	margin-bottom: 20px;
  	padding: 0 15px;
}
.register form input[type="submit"] {
  	width: 100%;
  	padding: 15px;
  	margin-top: 20px;
  	background-color: #23b574;
 	border: 0;
  	cursor: pointer;
  	font-weight: bold;
  	color: #ffffff;
  	transition: background-color 0.2s;
}
.register form input[type="submit"]:hover {
	background-color: #6633cc;
  	transition: background-color 0.2s;
}
</style>
</head>
<body bgcolor="#bbddff">
<style>
.login {
	box-sizing: border-box;
  	font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
  	font-size: 16px;
  	-webkit-font-smoothing: antialiased;
  	-moz-osx-font-smoothing: grayscale;
  	width: 400px;
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
  	margin: 300px auto;
}
.login h1 {
  	text-align: center;
  	color: #5b6574;
  	font-size: 24px;
  	padding: 20px 0 20px 0;
  	border-bottom: 2px solid #23b574;
}
.login form {
  	display: flex;
  	flex-wrap: wrap;
  	justify-content: center;
  	padding-top: 20px;
}
.login form label {
  	display: flex;
  	justify-content: center;
  	align-items: center;
  	width: 50px;
  	height: 50px;
  	background-color: #23b574;
  	color: #ffffff;
}
.login form input[type="password"], .login form input[type="text"] {
  	width: 310px;
  	height: 50px;
  	border: 1px solid #dee0e4;
  	margin-bottom: 20px;
  	padding: 0 15px;
}
.login form input[type="submit"] {
  	width: 100%;
  	padding: 15px;
 	margin-top: 20px;
  	background-color: #23b574;
  	border: 0;
  	cursor: pointer;
  	font-weight: bold;
  	color: #ffffff;
  	transition: background-color 0.2s;
}
.login form input[type="submit"]:hover {
	background-color: #6633cc;
  	transition: background-color 0.2s;
}
</style>
<div align="right" style="font-size:24px;"> <a class="wflbutton" style="font-size:22px; margin-right:10px; background-color:#6633cc; min-width:50px;" href="#" onClick="document.getElementById('modalboomlogin').style.visibility='visible'; return false;">Log In</a> <a class="wflbutton" style="font-size:22px; margin-right:25px; background-color:#6633cc; min-width:50px;" href="register.php">Sign Up</a> <a href="#"><img src="images/help.png" alt="?" title="Help" style="margin-right:3px; width:30px; vertical-align:middle; height:30px;" onClick="document.getElementById('videohelp2').style.visibility='visible'; return false;"></a>
</div>
<div id="videohelp2" style="position:fixed; visibility:hidden; padding:2% 5% 5% 5%; z-index: 8; background-color:#CDFFE6; min-width:50%; min-height:50%; top:25%; left:25%; margin-left:-5%; margin-top:-10% display: inline-block; cursor: pointer; border:1px solid black; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; overflow: auto;	border-radius: 25px; text-align:center;">
<div class="popupgridcloser"><span onClick="document.getElementById('videohelp2').style.visibility='hidden'; document.getElementById('bighelpvid2').src='https://www.youtube.com/embed/dq1N_-GQtEc';" style="font-size:20px; color:#ffffff; background-color:#ee2222; padding:4px; font-weight:bold;"> X </span><br></div>
<span style="text-align:center;">Find Fair Trades Quickly<br>
AdoptMeTradingValues.com How-To Video<br><br></span>
<iframe id="bighelpvid2" width="640" height="390" src="https://www.youtube.com/embed/dq1N_-GQtEc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
<div class="modal" id="modalboomlogin"><div class="login" id="loginscreen">
<div class="popupgridcloser" style="background-color:unset;"><span style="padding-right:45%; font-size:26px;">Log In</span> <span onClick="document.getElementById('modalboomlogin').style.visibility='hidden';" style="font-size:20px; color:#ffffff; background-color:#ee2222; padding:4px; font-weight:bold;"> X </span></div>
<form action="home.php" method="post">
<label for="username">
<img src="username.png" alt="UN" style="height:30px; width:30px;">
</label>
<input type="text" name="username" placeholder="Username" id="username" required>
<label for="password">
<img src="password.png" alt="PW" style="height:30px; width:30px;">
</label>
<input type="password" name="password" placeholder="Password" id="password" required>
<br><span align="center" style="font-size:small;"><a href="forgotpw.php">Forgot Password</a></span><br>
<input type="submit" value="Login">
</form>
</div></div><div align="center"><img src="images/header.png" alt="Roblox Adopt Me Trading Values">
<ul align="center">
<li><a href="index.php">W/F/L</a></li>
<li><a href="pet-value-list.php">Pet Value List</a></li>
<li><a href="play-games.php">Games</a></li>
<li><a href="videos.php">Videos</a></li>
<li><a href="tips-to-get-rich.php">Tips</a></li>
<li><a href="roblox-adopt-me.php">About</a></li>
</ul>
</div>
<div class="tradezoneupdates">
<div class="outergridupdates">
<div id="google_translate_element" style="text-align:right; display:inline;">
<script type="text/javascript">function googleTranslateElementInit() {  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, gaTrack: true, gaId: 'UA-3744414-1'}, 'google_translate_element');} </script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script></div>
<div style="font-size:20px; font-weight:bold;">
<u>Sign Up!</u><br><br>AdoptMeTradingValues.com now lets users offer on each others' pets. To get started, fill out the registration form below!<br>For more information, <a href="#" onClick="document.getElementById('videohelp2').style.visibility='visible'; return false;">watch this short video</a>.<br><br>
<div class="register">
<form action="register.php" method="post" autocomplete="off">
<label for="username">
<img src="username.png" alt="UN" style="height:30px; width:30px;">
</label>
<input type="text" name="username" placeholder="Username" id="username" maxlength="30" required>
<label for="password">
<img src="password.png" alt="PW" style="height:30px; width:30px;">
</label>
<input type="password" name="password" placeholder="Password" id="password" maxlength="30" required>
<label for="email">
<img src="email.png" alt="E" style="height:30px; width:30px;">
</label>
<input type="email" name="email" placeholder="Email" id="email" maxlength="320" required>
<label for="robloxusername">
<img src="robloxusername3.png" alt="RobloxUN" style="height:30px; width:30px;">
</label>
<input type="text" name="robloxusername" placeholder="Roblox Username*" id="robloxusername" maxlength="30" required>
<br><span style="font-weight:lighter; font-size:12px;"><i>* This will only be seen by users you trade with.</i></span>
<input type="submit" value="Register">
</form>
</div>
</div>
<br><br><br>
</div>
</div>
<div align="center">

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5814941088162332" crossorigin="anonymous"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5814941088162332" data-ad-slot="7684926393" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<br><br>
<div align="center"><i>Last updated July 7, 2022</i> - <a href="updates.php">View Update Log</a> | <a href="privacypolicy.php">Privacy Policy</a></div><br><br>

<script async src="https://www.googletagmanager.com/gtag/js?id=G-40249HE5LR"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-40249HE5LR');
</script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-60ba7e2fc1d62d27"></script>
</body>
</html>

<html>
<head>
<script data-ad-client="ca-pub-5814941088162332" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<link rel="icon" type="image/png" href="favicon.png" />
<title>Roblox Adopt Me Trading Values - About</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<style>
.tradezoneabout {
  background-color: #CDFFE6;
  border-radius: 25px;
  margin:2% 8% 2% 8%;
  text-align:left;
}
.outergridabout {
  display: grid;
  grid-template-columns: 100%;
  background-color: #CDFFE6;
  padding: 10px;
  border-radius: 25px;
  max-width:80%;
  margin: 0 auto;
}
.flier {
	pointer-events: auto; 
}

.flier > * {
/* Adjust animation duration to change the element’s speed */
        animation: fly 30s linear infinite;
        /*pointer-events: none !important;*/
	top: 0;
	left: 0;
	transform: translateX(-120%) translateY(-120%) rotateZ(0);
	position: fixed;
	animation-delay: 6s;
	z-index: 999999;
}

 /* Keyframe values control where the element will begin
    and end its trajectory across the screen. Each rule
    represents a path the element follows across the screen. */


@keyframes fly {

	98.001%, 0% {
                display: block;
		transform: translateX(-200%) translateY(100vh) rotateZ(0deg) rotateY(-180deg)
	}

	15% {
		transform: translateX(100vw) translateY(-100%) rotateZ(20deg) rotateY(180deg)
	}

	15.001%, 18% {
		transform: translateX(100vw) translateY(-30%) rotateZ(0deg) rotateY(180deg)
	}

	40% {
		transform: translateX(-200%) translateY(3vh) rotateZ(-20deg) rotateY(-180deg)
	}

	40.001%, 43% {
		transform: translateX(-200%) translateY(-100%) rotateZ(-20deg) rotateY(-180deg)
	}

	65% {
		transform: translateX(100vw) translateY(50vh) rotateZ(0deg) rotateY(180deg)
	}

	65.001%, 68% {
		transform: translateX(20vw) translateY(-200%) rotateZ(20deg) rotateY(180deg)
	}

	95% {
		transform: translateX(10vw) translateY(100vh) rotateZ(0deg) rotateY(180deg)
	}
}
</style>
</head>
<body bgcolor="#bbddff">
<style>
.login {
	box-sizing: border-box;
  	font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
  	font-size: 16px;
  	-webkit-font-smoothing: antialiased;
  	-moz-osx-font-smoothing: grayscale;
  	width: 400px;
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
  	margin: 300px auto;
}
.login h1 {
  	text-align: center;
  	color: #5b6574;
  	font-size: 24px;
  	padding: 20px 0 20px 0;
  	border-bottom: 2px solid #23b574;
}
.login form {
  	display: flex;
  	flex-wrap: wrap;
  	justify-content: center;
  	padding-top: 20px;
}
.login form label {
  	display: flex;
  	justify-content: center;
  	align-items: center;
  	width: 50px;
  	height: 50px;
  	background-color: #23b574;
  	color: #ffffff;
}
.login form input[type="password"], .login form input[type="text"] {
  	width: 310px;
  	height: 50px;
  	border: 1px solid #dee0e4;
  	margin-bottom: 20px;
  	padding: 0 15px;
}
.login form input[type="submit"] {
  	width: 100%;
  	padding: 15px;
 	margin-top: 20px;
  	background-color: #23b574;
  	border: 0;
  	cursor: pointer;
  	font-weight: bold;
  	color: #ffffff;
  	transition: background-color 0.2s;
}
.login form input[type="submit"]:hover {
	background-color: #6633cc;
  	transition: background-color 0.2s;
}
</style>
<div align="right" style="font-size:24px;"> <a class="wflbutton" style="font-size:22px; margin-right:10px; background-color:#6633cc; min-width:50px;" href="#" onClick="document.getElementById('modalboomlogin').style.visibility='visible'; return false;">Log In</a> <a class="wflbutton" style="font-size:22px; margin-right:25px; background-color:#6633cc; min-width:50px;" href="register.php">Sign Up</a> <a href="#"><img src="images/help.png" alt="?" title="Help" style="margin-right:3px; width:30px; vertical-align:middle; height:30px;" onClick="document.getElementById('videohelp2').style.visibility='visible'; return false;"></a>
</div>
<div id="videohelp2" style="position:fixed; visibility:hidden; padding:2% 5% 5% 5%; z-index: 8; background-color:#CDFFE6; min-width:50%; min-height:50%; top:25%; left:25%; margin-left:-5%; margin-top:-10% display: inline-block; cursor: pointer; border:1px solid black; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; overflow: auto;	border-radius: 25px; text-align:center;">
<div class="popupgridcloser"><span onClick="document.getElementById('videohelp2').style.visibility='hidden'; document.getElementById('bighelpvid2').src='https://www.youtube.com/embed/dq1N_-GQtEc';" style="font-size:20px; color:#ffffff; background-color:#ee2222; padding:4px; font-weight:bold;"> X </span><br></div>
<span style="text-align:center;">Find Fair Trades Quickly<br>
AdoptMeTradingValues.com How-To Video<br><br></span>
<iframe id="bighelpvid2" width="640" height="390" src="https://www.youtube.com/embed/dq1N_-GQtEc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
<div class="modal" id="modalboomlogin"><div class="login" id="loginscreen">
<div class="popupgridcloser" style="background-color:unset;"><span style="padding-right:45%; font-size:26px;">Log In</span> <span onClick="document.getElementById('modalboomlogin').style.visibility='hidden';" style="font-size:20px; color:#ffffff; background-color:#ee2222; padding:4px; font-weight:bold;"> X </span></div>
<form action="home.php" method="post">
<label for="username">
<img src="username.png" alt="UN" style="height:30px; width:30px;">
</label>
<input type="text" name="username" placeholder="Username" id="username" required>
<label for="password">
<img src="password.png" alt="PW" style="height:30px; width:30px;">
</label>
<input type="password" name="password" placeholder="Password" id="password" required>
<br><span align="center" style="font-size:small;"><a href="forgotpw.php">Forgot Password</a></span><br>
<input type="submit" value="Login">
</form>
</div></div><div align="center"><img src="images/header.png" alt="Roblox Adopt Me Trading Values">
<ul align="center">
<li><a href="index.php">W/F/L</a></li>
<li><a href="pet-value-list.php">Pet Value List</a></li>
<li><a href="play-games.php">Games</a></li>
<li><a href="videos.php">Videos</a></li>
<li><a href="tips-to-get-rich.php">Tips</a></li>
<li><a class="active" href="roblox-adopt-me.php">About</a></li>
</ul>
</div>
<div class="tradezoneabout">
<div class="outergridabout">
<div id="google_translate_element" style="text-align:right; display:inline;">
<script type="text/javascript">function googleTranslateElementInit() {  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, gaTrack: true, gaId: 'UA-3744414-1'}, 'google_translate_element');} </script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script></div>
<div style="font-size:20px; font-weight:bold;"><u>What is Roblox?</u><br><br><span style="font-size:18px; font-weight:normal;"><a href="https://roblox.com" target="_blank">Roblox</a> is a popular gaming platform used worldwide. It is free to download and play, either on a computer or as an installed app on a phone or tablet. There are over 40 million games to play within Roblox.</span><br><br></div>
<div> &nbsp; </div>
<div style="font-size:20px; font-weight:bold;"><u>What is Adopt Me?</u><br><br><span style="font-size:18px; font-weight:normal;">Adopt Me is the most popular game within Roblox. It has surpassed 20 billion visits and is constantly brimming with players.<br><br>Adopt Me allows players to collect and trade pets, vehicles, toys, and other items. All of these items have different values which makes trading very interesting.<br><img src="images/screenshot2.jpg" alt="screenshot" style="object-fit: cover; width: 100%; max-height: 100%;"></span><br><br></div>
<div style="font-size:20px; font-weight:bold;"><u>What is the purpose of this website?</u><br><br><span style="font-size:18px; font-weight:normal;">AdoptMeTradingValues.com exists to help Adopt Me players know if a trade is good or bad. Is a trade a big win? Is it fair? Just add the pets or other items to the <a href="http://adoptmetradingvalues.com">trading grid</a> on this website, and you will instantly get the answer.</span><br><br></div>
<div> &nbsp; </div>
<div style="font-size:20px; font-weight:bold;">
<div align="center"><script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5814941088162332" data-ad-slot="1545665476" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
			 (adsbygoogle = window.adsbygoogle || []).push({});
		</script><br></div></div>
<div> &nbsp; </div>
<div style="font-size:20px; font-weight:bold;"><u>How did this website determine the values of pets, vehicles, etc.?</u><br><br><span style="font-size:18px; font-weight:normal;">The values of all items were determined by three long-time Adopt Me players. Collectively, the team here has participated in thousands of trades. We use that experience along with research on other trading websites to determine the value of every pet and other item in the game. Ultimately, a pet or other item is only worth what a reasonable person would offer for it.<br><br>Note: AdoptMeTradingValues.com is an independent website that is not run by Roblox employees or Adopt Me/Dreamcraft employees.<br><img src="images/screenshot1.jpg" alt="screenshot" style="object-fit: cover; width: 100%; max-height: 100%;"></span><br><br></div>
<div style="font-size:20px; font-weight:bold;"><u>Are the values accurate?</u><br><br><span style="font-size:18px; font-weight:normal;">The values are as accurate as possible based on the available information. It is impossible for every value to be 100% accurate all the time though. Values also change over time. If we notice that many players are suddenly making higher offers for certain items, we will increase the value of those items. If we notice that only lower offers are being made on certain items, we will decrease the value of those items. Our goal is for all items to at least be within the ballpark range of what it is really worth so our users can have confidence that they know whether their trades are wins, losses, or fair.<br><br>See the <i>Important Notes About Values</i> section of the <a href="tips-to-get-rich.php">Tips</a> page for some surprising facts about the values of certain types of pets.</span> <br><br></div>
<div> &nbsp; </div>
<div style="font-size:20px; font-weight:bold;"><u>Submitting feedback...</u><br><br><span style="font-size:18px; font-weight:normal;">Visitors of this website can submit feedback to the AdoptMeTradingValues.com team. Feedback about particular item values, website functionality, or other inquiries can be submitted through <a href="https://forms.gle/NqYKfCCRtJrSP1fQ6" target="_blank">this Google Form</a>.</span><br><br><br></div>
</div>
</div>
<div class="flier"><img id="bbb" src="images/3.png" alt="Ahhh! Flying Pet!" title="Ahhh! Flying Pet!"></div>
<script>
var audio1 = new Audio("laugh.mp3");
function playAudio() {
  audio1.currentTime = 0; audio1.play();
}

document.getElementById("bbb").addEventListener("click", function() {
  playAudio();
});
</script>
<div align="center">

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5814941088162332" crossorigin="anonymous"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5814941088162332" data-ad-slot="7684926393" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<br><br>
<div align="center"><i>Last updated July 7, 2022</i> - <a href="updates.php">View Update Log</a> | <a href="privacypolicy.php">Privacy Policy</a></div><br><br>

<script async src="https://www.googletagmanager.com/gtag/js?id=G-40249HE5LR"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-40249HE5LR');
</script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-60ba7e2fc1d62d27"></script>
</body>
</html>

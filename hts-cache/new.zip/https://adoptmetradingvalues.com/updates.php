<html>
<head>
<script data-ad-client="ca-pub-5814941088162332" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<link rel="icon" type="image/png" href="favicon.png" />
<title>Roblox Adopt Me Trading Values - Update Log</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<style>
.tradezoneupdates {
  background-color: #CDFFE6;
  border-radius: 25px;
  margin:2% 8% 2% 8%;
  text-align:left;
}
.outergridupdates {
  display: grid;
  grid-template-columns: 100%;
  background-color: #CDFFE6;
  padding: 10px;
  border-radius: 25px;
  max-width:80%;
  margin: 0 auto;
}

.flier {
	pointer-events: auto; 
}

.flier > * {
/* Adjust animation duration to change the element’s speed */
        animation: fly 30s linear infinite;
        /*pointer-events: none !important;*/
	top: 0;
	left: 0;
	transform: translateX(-120%) translateY(-120%) rotateZ(0);
	position: fixed;
	animation-delay: 6s;
	z-index: 999999;
}

 /* Keyframe values control where the element will begin
    and end its trajectory across the screen. Each rule
    represents a path the element follows across the screen. */


@keyframes fly {

	98.001%, 0% {
                display: block;
		transform: translateX(-200%) translateY(100vh) rotateZ(0deg) rotateY(-180deg)
	}

	15% {
		transform: translateX(100vw) translateY(-100%) rotateZ(20deg) rotateY(180deg)
	}

	15.001%, 18% {
		transform: translateX(100vw) translateY(-30%) rotateZ(0deg) rotateY(180deg)
	}

	40% {
		transform: translateX(-200%) translateY(3vh) rotateZ(-20deg) rotateY(-180deg)
	}

	40.001%, 43% {
		transform: translateX(-200%) translateY(-100%) rotateZ(-20deg) rotateY(-180deg)
	}

	65% {
		transform: translateX(100vw) translateY(50vh) rotateZ(0deg) rotateY(180deg)
	}

	65.001%, 68% {
		transform: translateX(20vw) translateY(-200%) rotateZ(20deg) rotateY(180deg)
	}

	95% {
		transform: translateX(10vw) translateY(100vh) rotateZ(0deg) rotateY(180deg)
	}
}
</style>
</head>
<body bgcolor="#bbddff">
<style>
.login {
	box-sizing: border-box;
  	font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
  	font-size: 16px;
  	-webkit-font-smoothing: antialiased;
  	-moz-osx-font-smoothing: grayscale;
  	width: 400px;
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
  	margin: 300px auto;
}
.login h1 {
  	text-align: center;
  	color: #5b6574;
  	font-size: 24px;
  	padding: 20px 0 20px 0;
  	border-bottom: 2px solid #23b574;
}
.login form {
  	display: flex;
  	flex-wrap: wrap;
  	justify-content: center;
  	padding-top: 20px;
}
.login form label {
  	display: flex;
  	justify-content: center;
  	align-items: center;
  	width: 50px;
  	height: 50px;
  	background-color: #23b574;
  	color: #ffffff;
}
.login form input[type="password"], .login form input[type="text"] {
  	width: 310px;
  	height: 50px;
  	border: 1px solid #dee0e4;
  	margin-bottom: 20px;
  	padding: 0 15px;
}
.login form input[type="submit"] {
  	width: 100%;
  	padding: 15px;
 	margin-top: 20px;
  	background-color: #23b574;
  	border: 0;
  	cursor: pointer;
  	font-weight: bold;
  	color: #ffffff;
  	transition: background-color 0.2s;
}
.login form input[type="submit"]:hover {
	background-color: #6633cc;
  	transition: background-color 0.2s;
}
</style>
<div align="right" style="font-size:24px;"> <a class="wflbutton" style="font-size:22px; margin-right:10px; background-color:#6633cc; min-width:50px;" href="#" onClick="document.getElementById('modalboomlogin').style.visibility='visible'; return false;">Log In</a> <a class="wflbutton" style="font-size:22px; margin-right:25px; background-color:#6633cc; min-width:50px;" href="register.php">Sign Up</a> <a href="#"><img src="images/help.png" alt="?" title="Help" style="margin-right:3px; width:30px; vertical-align:middle; height:30px;" onClick="document.getElementById('videohelp2').style.visibility='visible'; return false;"></a>
</div>
<div id="videohelp2" style="position:fixed; visibility:hidden; padding:2% 5% 5% 5%; z-index: 8; background-color:#CDFFE6; min-width:50%; min-height:50%; top:25%; left:25%; margin-left:-5%; margin-top:-10% display: inline-block; cursor: pointer; border:1px solid black; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; overflow: auto;	border-radius: 25px; text-align:center;">
<div class="popupgridcloser"><span onClick="document.getElementById('videohelp2').style.visibility='hidden'; document.getElementById('bighelpvid2').src='https://www.youtube.com/embed/dq1N_-GQtEc';" style="font-size:20px; color:#ffffff; background-color:#ee2222; padding:4px; font-weight:bold;"> X </span><br></div>
<span style="text-align:center;">Find Fair Trades Quickly<br>
AdoptMeTradingValues.com How-To Video<br><br></span>
<iframe id="bighelpvid2" width="640" height="390" src="https://www.youtube.com/embed/dq1N_-GQtEc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
<div class="modal" id="modalboomlogin"><div class="login" id="loginscreen">
<div class="popupgridcloser" style="background-color:unset;"><span style="padding-right:45%; font-size:26px;">Log In</span> <span onClick="document.getElementById('modalboomlogin').style.visibility='hidden';" style="font-size:20px; color:#ffffff; background-color:#ee2222; padding:4px; font-weight:bold;"> X </span></div>
<form action="home.php" method="post">
<label for="username">
<img src="username.png" alt="UN" style="height:30px; width:30px;">
</label>
<input type="text" name="username" placeholder="Username" id="username" required>
<label for="password">
<img src="password.png" alt="PW" style="height:30px; width:30px;">
</label>
<input type="password" name="password" placeholder="Password" id="password" required>
<br><span align="center" style="font-size:small;"><a href="forgotpw.php">Forgot Password</a></span><br>
<input type="submit" value="Login">
</form>
</div></div><div align="center"><img src="images/header.png" alt="Roblox Adopt Me Trading Values">
<ul align="center">
<li><a href="index.php">W/F/L</a></li>
<li><a href="pet-value-list.php">Pet Value List</a></li>
<li><a href="play-games.php">Games</a></li>
<li><a href="videos.php">Videos</a></li>
<li><a href="tips-to-get-rich.php">Tips</a></li>
<li><a href="roblox-adopt-me.php">About</a></li>
</ul>
</div>
<div class="tradezoneupdates">
<div class="outergridupdates">
<div id="google_translate_element" style="text-align:right; display:inline;">
<script type="text/javascript">function googleTranslateElementInit() {  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, gaTrack: true, gaId: 'UA-3744414-1'}, 'google_translate_element');} </script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script></div>
<div style="font-size:20px; font-weight:bold;"><u>Latest Updates (July 2022)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; There has been a lot of movement on the value of the Space Whale, Capricorn, Chick, and Easter 2020 Egg. The biggest change is in regard to the Chick which has really dropped heavily in value over the past week (including its Neon & Mega versions).<br><br>Also, Adopt Me staff announced this week that pets from the Cracked/Pet/Royal eggs will be moved to a new Retired Egg. Brand new pets will then be moved into the Cracked/Pet/Royal eggs. We will be watching closely to see how this impacts pet values. We recommend stocking up on Cracked/Pet/Royal eggs/bucks so you can get the new pets as soon as they come out (July 21). These will be in high demand since players will want to make/trade for Neons and Megas.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of June 28 through July 4, 2022.</span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (June 2022)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new pet trading video to the <a href="videos.php">Videos</a> page. The video is titled Trading a Space Whale.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Issue report - we ran into an issue today that resulted in all dream pets getting messed up. Thank you to DharcSlayerOfficial for bringing this to our attention. We have determined the best way to resolve the problem is to clear everyone's dream pet. Users should choose new dream pets when ready. This can be done from the Home page while logged in. It will be interesting to see which pet is the most wanted nowadays. Sorry for the inconvenience.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of June 20 through June 26, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the Chick and the Easter 2020 Egg since they can now be traded. Also added a new video titled "Chick Trading Explosion in Adopt Me" to the <a href="videos.php">Videos</a> page.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of dozens of Neon and Mega Neon pets.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of June 12 through June 18, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the Zodiac Minion Egg and Zodiac Minion Chick.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of June 5 through June 11, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added in the rest of the Pride Event 2022 items, including all the pins, flags, etc. Most of them are very low value since they are either free or just 50 bucks. Some of the non-pin items may very slowly go up in value once they leave the game after the event.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; We have seen the value of many of the top pets rise over the past month, so we have boosted the values of many of the highest valued pets. This includes lots of Neons and Mega Neons. Also added the new Robux pet Goat.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of May 29 through June 4, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of a few pets. We made a large increase in the value of the Yeti (and Neon & Mega Neon versions), boosted the Dalmatian back up after it had been down for a month or two, and made a handful of other changes.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; New Feature: Users can now create their own Value Lists! We have heard from tons of users who have their own opinions about which pets are worth more or less than others. Now users can share their opinions by creating their own value lists. The most liked value lists will rise to the top of the heap. To save you time, we start you off with our current value list. You just need to drag and drop items to make changes. You can then share your Value List with other players via the provided link.<br><br>Watch our new video all about it on the <a href="videos.php">Videos</a> page.</span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (May 2022)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; New Feature: Added user profile pages. These pages display a user's ratings, dream pet, and inventory/listings. Users can view their own profiles/inventories by clicking the profile icon in the top right while logged in. They can then share this page with others to let them easily view all the items in their inventory. Users can also view other users' profiles by clicking the profile icon on the Recent Offers and View Offers screens.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of May 20 through May 26, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Completed upgrade of our web server. We hope this move will improve performance for all users.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the two new pets: Ibex (980 bucks) and Winged Horse (800 Robux). The Winged Horse is high in demand which has boosted its value while the Ibex does not seem to have very high demand which has kept its value relatively low.<br><br>We are also in the process of upgrading our web server this week. We apologize for any downtime or issues you may experience.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new trading video to the <a href="videos.php">Videos</a> page. The video is called Trading 4 Mega Neon Pets - May 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of May 10 through May 16, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added all of the Snow Weather pets and items.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of May 1 through May 7, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of over 200 pets and items based on recent trade activity. Players still love the pet Rock and most out of game pets and items continue to gain value.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new pet trading video to the <a href="videos.php">Videos</a> page. The video is called Trading a FR Evil Unicorn.</span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (April 2022)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the two new Accessory Chests and all the items they contain. The chests are relatively inexpensive, and it looks like they are planned to be in game permanently, so values of most items are low already. Also added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of April 23, 2022 through April 29, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Lowered the values of most RGB items as their values continue to decline since they are becoming more and more common. Also lowered the value of some Easter 2022 items, though we do anticipate the value of those will very slowly go back up after the event ends.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of April 14, 2022 through April 20, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a video titled Adopt Me Easter Egg Locations in Order - April 2022. Check out this video if you need help finding the locations of all 30 Easter eggs. Good luck!</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of over 200 pets and other items based on recent trades. Values of Woodland pets have gone down a bit since their freshness has worn off. Many older items nudged up in value as expected.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of April 7, 2022 through April 13, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Glitch alert! Due to a bug in a recent update, new users who signed up between April 10th and April 12th might need to sign up again freshly. If you registered within those dates and find that your listings and offers are not showing up in your My Listings and My Offers, then this is probably the case. Please sign up again. The issue has been resolved and we apologize for the inconvenience.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new feature to the website. You can now block another user from accepting your offers. You can only do this to a user who has already accepted one of your offers. First, find one of your offers that he/she accepted. Next, mark the trade as being failed due to their fault. Finally, on the My Offer History page, click the option to block that user from accepting any more of your trades.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of March 27, 2022 through April 2, 2022.</span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (March 2022)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added in the new vehicles, new gift rotation items, Rock pet, and Mechapup pet.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of nearly 300 pets and other items based on recent trading activity. Also increased the value of the highest tier non-potion Neon and Mega pets.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of March 19, 2022 through March 25, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added new feature to the Recent Offers section. There is no a "Most Recent Offers on My Listings" button. This button will show you ONLY the new offers that have come on the items that you have currently listed in the My Listings section. For example, if you currently have 20 Pets in the My Listings section, this new button will show you the most recent offers on ONLY those 20 pets. All the pets and other items that you have not yet listed will be filtered out. We hope this feature saves you time and helps you be accept the best new offers quickly!</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Reduced the value of most RGB items. More and more of these are being won by players every day which has brought the values down. We expect this trend to slowly continue over time. We have also updated the values of dozens of other pets and items.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; The new Woodland Egg is now out (3/17/2022)! All of the Woodland Egg pets have been added. The next week or so will be a great chance to get a great trade on a Legendary Fallow Deer or Hawk if you are able to hatch one. Also added in all of the new camping items. </span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of March 11, 2022 through March 17, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of many mid-tier legendary Mega Neon pets. Thanks to our users for the feedback to make us aware that an adjustment was needed on some of these!</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Problem detected. On March 11 at 8:20EST, our website experienced an issue that caused most offers & listings to disappear. We are investigating the cause of the issue. We were able to restore most of the listings and offers, but some information regarding which ones were completed, canceled, etc. has been lost (at least temporarily but possibly permanently). Information regarding number of trades completed and failed by each user has not been impacted. Users may need to double check their offers and cancel any that are set as Active but shouldn't be. We apologize for the inconvenience and will continue to look into the cause.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of March 2, 2022 through March 8, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the seven new vehicles from the Vehicle Dealership update.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new trading video to the <a href="videos.php">Videos</a> page. The video is called <i>Trading a Neon Fly Ride Phoenix.</i>.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of February 23, 2022 through March 1, 2022.</span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (February 2022)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of February 15, 2022 through February 21, 2022. Also updated the value of over 150 pets and other items based on recent trades.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the 2 new Robux taxi vehicles. Updated the value of over 200 pets and other items based on recent trades.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added Abyssinian Cat which is a new rare pet released under this month's Desert Weather Map. It costs 750 bucks (same as a Mythic Egg), but is only available while the Desert Weather Map is active.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of February 8, 2022 through February 14, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; We have been implementing a variety of improvements to optimize the speed and availability of the website. Our most recent step was to temporarily remove old offers and listings that were well over a month old. We find that offers that are over a week old rarely become Completed trades. We also find that listings over a month old rarely become Completed offers. Note that these old listings and offers have not been lost and can possibly be restored at some point. We will look into providing access to these older listings again in the future, but for now we want to focus on seeing how this impacts speed and availability of the website. Thank you for your patience.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the new Lavender Dragon pet. This pet was awarded to players who had the DJ gamepass to compensate them since that gamepass recently broke due to a Roblox update. Also updated the values of nearly 200 pets and other items based on recent trades.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of February 2, 2022 through February 7, 2022.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added all of the new Lunar New Year 2022 pets and items. The new Lunar Tiger pets seem like their values will follow the same trend as the Ox/Lunar Ox/Metal Ox. The first couple days they will have decent values, but their values will go down and not come back up very high even several months after the event is over. The Dancing Dragon, on the other hand, will likely end up following a similar trend to the Halloween White Ghost Dragon and Frost Fury.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of January 26, 2022 through February 1, 2022. Also updated the value of over 150 pets and items based on recent activity. Note that value updates only impact new offers. Older offers still display with older values, so keep in mind that newer offers are often graded more accurately since values change over time.</span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (January 2022)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of January 26, 2022 through February 1, 2022. Also updated the value of many pets based on recent activity.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added all of the new RGB items. These items can be obtained by opening RGB Reward Boxes that players earn through the new Task Board.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new trading video to the <a href="videos.php">Videos</a> page. The video is called <i>Trading a Frost Dragon.</i>.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; All of the Desert Weather Map items have been added. These items are planned to stay in game for a couple days, then be gone, then return in a month or so. This is most similar to how items in the Hat Shop are handled. They are brand new now so their values are inflated. We expect their values to gradually go down in value as more of the items flood the market.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of January 13, 2022 through January 19, 2022. Also updated the value of many pets based on recent activity.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of January 6, 2022 through January 12, 2022. Also optimized the loading speed of a few functions on the site & updated the value of many pets based on recent activity.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new trading video to the <a href="videos.php">Videos</a> page. The video is called <i>Trading a Fly Ride Parrot.</i>.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the two new vehicles (Zamboni and Snowmobile).</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new Biggest Wins of the Week video to the <a href="videos.php">Videos</a> page. The video is for the week of December 30, 2021 through January 5, 2022.</span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (December 2021)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new trading video to the <a href="videos.php">Videos</a> page. The video is called <i>Trading a Fly Ride Crow.</i>.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added <a href="videos.php">video</a> showing the Biggest Wins of the week (December 23 through December 29, 2021). Also updated many values based on recent activity.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new <a href="play-games.php">Games</a> section of the website to house our existing Know Your Values game. Also added a brand new game: Know Your Facts. This game quizzes players about the origin and rarity of pets and other items from Adopt Me. Good luck and enjoy!</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added <a href="videos.php">video</a> showing the Biggest Wins of the week (December 15 through December 21, 2021). Also added additional Winter 2021 items and increased some of the mid-tier older pet values.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Further increased the values of many of the highest value pets and items. This creates more separation between them and the rest of the pets and items to better reflect the most common values paid for them nowadays.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added feature to allow players to sort their listings by Best Offers First. Some items now have hundreds of offers on them, so this feature should help save some time so you see the best ones first. Thanks to an anonymous user for suggesting this feature.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of many pets & items and added in more of the new Advent Calendar items.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added <a href="videos.php">video</a> showing the Biggest Wins of the week (December 1 through December 7, 2021). </span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of about 100 pets and other items based on recent trade activity. </span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the Winter 2021 toys that are currently available. Some of these toys may take several hours of work to be able to get (since the maximum gingerbread for each game seems to be 1200 and some toys are over 20,000 gingerbread), but we do not expect the values to be too high since toys rarely become high value items. We will try to keep an eye on them and update values as we see changes.<br><br>As for the Winter 2021 pets, we are seeing the normal trend of new pet values so far. First, values are very high. Then they slowly go down. Then once they are out of game, they slowly go back up again. We'll see if that trend continues here.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the new Winter 2021 pets except for St. Bernard which will not be available until the 25th day of the Advent calendar. We will add the other Winter 2021 items soon.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">
<div align="center">
<style>
				.mf_responsive_1 { width: 300px; height: 250px; }
				@media(min-width: 500px) { .mf_responsive_1 { width: 300px; height: 250px; } }
				@media(min-width: 800px) { .mf_responsive_1 { width: 300px; height: 250px; } }
				</style>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5814941088162332" crossorigin="anonymous"></script>

<ins class="adsbygoogle mf_responsive_1" style="display:inline-block;min-width:400px;max-width:970px;width:100%;" data-ad-client="ca-pub-5814941088162332" data-ad-slot="1545665476"></ins>
<script>
				(adsbygoogle = window.adsbygoogle || []).push({});
				</script>
</div>
<br></span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (November 2021)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of many pets and other items based on recent trades.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; New feature! Click "<a href="know-your-values-game.php">KYV Game</a>" on the main menu to play a new game based on all the pets and items in Adopt Me. The game is called Know Your Values. To play, click on the item that is worth more (or click on Fair if both items are equal in value). Try to get as many correct in a row as you can. If you are logged in, your high score will be saved. There is also a High Score Leaderboard where you can see how your score compares to other AdoptMeTradingValues.com users. Can you reach the top of the leaderboard?</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of many pets. Also fixed a bug with going to the Next Page of offers made on listings. Thanks to Flamingo1girl for pointing this out!</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added "Recent Trades" section to the <a href="https://adoptmetradingvalues.com/what-is-worth.php">Pet & Item Information</a> page. Just click to view a particular pet or item, and you can now see trades recently completed for that item.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the Halloween toys and the rest of the Halloween 2021 permanently tradable items.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added another new feature to the new trading system. Click Recent Offers and then click "Best Offers Not Yet Accepted from the Past 24 Hours" to see all the best recent offers (sorted by the biggest win percentage-wise).<br><br>Also added additional functionality to further limit ridiculous trades. Trades like Dog for Shadow Dragon were already blocked, but this latest update should reduce the number of highly unbalanced offers in the future while still allowing users to be reasonably over.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added "Recent Offers" button to our new trading system. This new feature lets users see what offers have just been made most recently by other players. Refresh the Recent Offers every few minutes to see what new offers have been made so you can be the first to accept the offer and complete the trade right away since the other user is very likely to still be online.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Users can now log into AdoptMeTradingValues.com to find trades with each other. When you list an item, you will see all offers made on that item by all users. When you make an offer for an item, all users who are listing that item will see your offer. You will also be able to see the Win/Fair/Lose suggestions. Click the help question mark in the top right to learn more about how this works and why you might want to sign up.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added ability to easily see how many users have set each pet as their dream pet so far. To see this dream pet info, check out the <a href="https://adoptmetradingvalues.com/what-is-worth.php?q=pets&sort=numusers">Pet & Item Information</a> page.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Removed Full Grown as an option when adding a Mega Neon pet. Thanks to anonymous user for the suggestion!</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the Halloween Pet Wear.</span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (October 2021)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added all the Halloween 2021 event pets. The Halloween Pet Wear & Toys will be coming sometime after Roblox is back online.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated many pet values, particularly the higher value pets.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; We have been working behind the scenes to prepare a new system where users can trade items online with other users. The goal of the system is to make it easier and quicker for Adopt Me players to get fair trades. We will post an announcement on the home page once it is ready.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added all the new Pet Wear.</span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (September 2021)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new trading video to the <a href="videos.php">Videos</a> page. The video is called <i>Trading a FR Frost Fury.</i>.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added a new trading video to the <a href="videos.php">Videos</a> page. The video is called <i>Trading a FR Arctic Reindeer</i>.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the 2 new flying vehicles and Mooncakes.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added all the newest gifts from the latest gift rotation. All tradable items should now be on the site.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; All Pet Wear has now been added. Also added option for "Pet Wear Only" to the Value List page.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added another new trading video to the <a href="videos.php">Videos</a> page. The video is called <i>Trading A Neon FR Unicorn</i>.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added more Pet Wear. We will add the rest soon.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added new video to the <a href="videos.php">Videos</a> page. The video is called <i>Making & Trading A Neon FR Turtle</i>.</span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (August 2021)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added more Pet Wear and adjusted the value of many out of game pets. The release of the Mythic Egg has finally started to settle down a bit, so values of Mythic Egg pets have gone down a bit as well.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Adjusted many more pet values - particularly higher value pets. Of special note, we have been resisting placing the Bat Dragon above the Giraffe (we know many of you have been suggesting this for a while, thank you), but this is now clearly the case. Thanks to all who make suggestions on updating values. We don't always follow the advice of the suggestions, but we do always double check them based on current values that we see and try to provide an accurate ballpark estimate value.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; We will be adding the ability to let users log into the website and perform a variety of actions soon. We have already added functionality to show the number of users who have certain pets as their Dream Pets (though nearly all of them will show 0 for now until we let all users log in to select their dream pets). More coming soon...</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Adjusted many pet values. Phoenix and Goldhorn now seem to be trading for about the same values (August 21). Added many more Pet Wear items.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added Mythic Egg and all the Mythic Egg pets. They just came out today (August 19), and their values are temporarily high as expected. Although the Goldhorn and Phoenix are both legendary, we are seeing the Goldhorn trade for more than the Phoenix currently. We will keep our eyes on values, but they should all start to decline over the next few days.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Started adding Pet Wear to the trading grid. There are over 230 Pet Wear items, so we will add them in batches over time. They are also now available on the Pet Value List page when selecting the Everything option.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added the Speedboat and three new Robux/Gamepass vehicles.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Increased value of some of the oldest legendary pets when they are unpotioned. For example, a non-fly/non-ride Giraffe now shows up as being worth more than a Fly/Ride Giraffe.</span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (July 2021)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added Search to the trading grid.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; All toys have now been added.</span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added Toys options to both the <a href="pet-value-list.php">Value List</a> page and the <a href="what-is-worth.php">Item Information</a> pages. We are almost done adding all toys to the website.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added new page with information about <a href="tips-to-get-rich.php">Tips to Get Rich</a>.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added Neon and Mega Neon versions of pets to the individual pet information value pages found <a href="what-is-worth.php">here</a>.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated some pet values & added more toys.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added Fossil Egg trading video to the Videos page.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; On the individual item information pages linked below, Neons and Mega-Neons are now included in the list of items that are close in value to the item being viewed.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added information pages for all pets and other items currently available: <a href="what-is-worth.php?q=pets">Pets</a> | <a href="what-is-worth.php?q=vehicles">Vehicles</a> | <a href="what-is-worth.php?q=foods">Food</a> | <a href="what-is-worth.php?q=strollers">Strollers</a><br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated values of some pets and items & added more toys.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Started adding Toys to the trading grid. There are over 240 of them, so we will add them in batches over time. They are also now available on the Pet Value List page when selecting the Everything option.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Hmmm... some of the pets around here really want some attention. We hear they like to be tickled. Try clicking on a floating pet with your sound turned on.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added "W/F/L?" button to the trading grid.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the trading grid screen to make it clearer when a trade is a Win, Lose, or Fair. Green colors indicate a good trade (W/F) while red colors indicate a bad trade (L).<br></span>
<div> &nbsp; </div>
</div>
<div style="font-size:20px; font-weight:bold;"><u>Older Updates (June 2021)</u><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; The Stroller list now contains all strollers.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Implemented HTTPS so the website should now show up as Secure within user web browsers.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of many pets (Dalmatian, Christmas Egg, Diamond Egg & its pets, and more).<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added help icon to home page and new tutorial video to help demonstrate how to use the site for new users.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added pet icons to the Videos page. Users can now click on a pet to go directly to that pet's part of the video.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Began adding Strollers to the trading grid. More will be added soon. Also added Strollers to the Everything option of the Pet Valu List page.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Improved website loading speed by making multiple major changes. Sorry for any slowness experienced this week.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added new Videos section and our first video (Ocean Egg Pet Trading).<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added Gifts to the trading grid. Gifts are also now included in the "Everything" option of the Pet Value List page.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added "Foods Only" option to the Pet Value List page. Also added "Everything" option so all items added so far can be viewed in comparison to each other.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; The Food list now contains all food items.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated the values of several pets, including some neon values.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added additional items to the list of Foods in the trading grid.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Reduced the file size of images so pages load faster over slow connections.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added new Legendary pet Cobra.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added all remaining potions and some other items to the list of available Foods in the trading grid.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added Vehicles to the <a href="pet-value-list.php">Pet Value List</a> page. You can still view the Pet Value List with just pets, but now you can also view the values of Vehicles by themselves or even view Pets & Vehicles together on one page. Use the drop-down menu at the top of that page to make your selection.<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added names, rarity, and origin to items when you hover over them. For example, if you hover over a Turtle, you will see "Turtle - Legendary from Aussie Egg."<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Updated values of some golden pets, some other pets, and some vehicles. Thank you to those who have submitted feedback via our feedback form!<br></span>
<div> &nbsp; </div>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px;">&#10004; Added Numbers to the <a href="pet-value-list.php">Pet Value List</a> page to make it easier to understand the tiers of values.<br></span>
</div>
<div> &nbsp; </div>
<br><br><br>
</div>
</div>
<div class="flier"><img id="bbb" src="images/90.png" alt="Ahhh! Flying Pet!" title="Ahhh! Flying Pet!"></div>
<br>
<script>
var audio1 = new Audio("laugh.mp3");
function playAudio() {
  audio1.currentTime = 0; audio1.play();
}

document.getElementById("bbb").addEventListener("click", function() {
  playAudio();
});
</script>
<div align="center">

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5814941088162332" crossorigin="anonymous"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5814941088162332" data-ad-slot="7684926393" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<br><br>
<div align="center"><i>Last updated July 7, 2022</i> - <a href="updates.php">View Update Log</a> | <a href="privacypolicy.php">Privacy Policy</a></div><br><br>

<script async src="https://www.googletagmanager.com/gtag/js?id=G-40249HE5LR"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-40249HE5LR');
</script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-60ba7e2fc1d62d27"></script>
</body>
</html>

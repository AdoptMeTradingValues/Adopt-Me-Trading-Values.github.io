<html>
<head>
<script data-ad-client="ca-pub-5814941088162332" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<link rel="icon" type="image/png" href="favicon.png" />
<title>Roblox Adopt Me Trading Values - Videos</title>
<link rel="stylesheet" type="text/css" href="styles.css">
<style>
.tradezonevideos {
  background-color: #CDFFE6;
  border-radius: 25px;
  margin:2% 8% 2% 8%;
  text-align:left;
}
.outergridvideos {
  display: grid;
  grid-template-columns: 100%;
  background-color: #CDFFE6;
  padding: 10px;
  border-radius: 25px;
  max-width:80%;
  margin: 0 auto;
}
</style>
</head>
<body bgcolor="#bbddff">
<style>
.login {
	box-sizing: border-box;
  	font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
  	font-size: 16px;
  	-webkit-font-smoothing: antialiased;
  	-moz-osx-font-smoothing: grayscale;
  	width: 400px;
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
  	margin: 300px auto;
}
.login h1 {
  	text-align: center;
  	color: #5b6574;
  	font-size: 24px;
  	padding: 20px 0 20px 0;
  	border-bottom: 2px solid #23b574;
}
.login form {
  	display: flex;
  	flex-wrap: wrap;
  	justify-content: center;
  	padding-top: 20px;
}
.login form label {
  	display: flex;
  	justify-content: center;
  	align-items: center;
  	width: 50px;
  	height: 50px;
  	background-color: #23b574;
  	color: #ffffff;
}
.login form input[type="password"], .login form input[type="text"] {
  	width: 310px;
  	height: 50px;
  	border: 1px solid #dee0e4;
  	margin-bottom: 20px;
  	padding: 0 15px;
}
.login form input[type="submit"] {
  	width: 100%;
  	padding: 15px;
 	margin-top: 20px;
  	background-color: #23b574;
  	border: 0;
  	cursor: pointer;
  	font-weight: bold;
  	color: #ffffff;
  	transition: background-color 0.2s;
}
.login form input[type="submit"]:hover {
	background-color: #6633cc;
  	transition: background-color 0.2s;
}
</style>
<div align="right" style="font-size:24px;"> <a class="wflbutton" style="font-size:22px; margin-right:10px; background-color:#6633cc; min-width:50px;" href="#" onClick="document.getElementById('modalboomlogin').style.visibility='visible'; return false;">Log In</a> <a class="wflbutton" style="font-size:22px; margin-right:25px; background-color:#6633cc; min-width:50px;" href="register.php">Sign Up</a> <a href="#"><img src="images/help.png" alt="?" title="Help" style="margin-right:3px; width:30px; vertical-align:middle; height:30px;" onClick="document.getElementById('videohelp2').style.visibility='visible'; return false;"></a>
</div>
<div id="videohelp2" style="position:fixed; visibility:hidden; padding:2% 5% 5% 5%; z-index: 8; background-color:#CDFFE6; min-width:50%; min-height:50%; top:25%; left:25%; margin-left:-5%; margin-top:-10% display: inline-block; cursor: pointer; border:1px solid black; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; overflow: auto;	border-radius: 25px; text-align:center;">
<div class="popupgridcloser"><span onClick="document.getElementById('videohelp2').style.visibility='hidden'; document.getElementById('bighelpvid2').src='https://www.youtube.com/embed/dq1N_-GQtEc';" style="font-size:20px; color:#ffffff; background-color:#ee2222; padding:4px; font-weight:bold;"> X </span><br></div>
<span style="text-align:center;">Find Fair Trades Quickly<br>
AdoptMeTradingValues.com How-To Video<br><br></span>
<iframe id="bighelpvid2" width="640" height="390" src="https://www.youtube.com/embed/dq1N_-GQtEc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
<div class="modal" id="modalboomlogin"><div class="login" id="loginscreen">
<div class="popupgridcloser" style="background-color:unset;"><span style="padding-right:45%; font-size:26px;">Log In</span> <span onClick="document.getElementById('modalboomlogin').style.visibility='hidden';" style="font-size:20px; color:#ffffff; background-color:#ee2222; padding:4px; font-weight:bold;"> X </span></div>
<form action="home.php" method="post">
<label for="username">
<img src="username.png" alt="UN" style="height:30px; width:30px;">
</label>
<input type="text" name="username" placeholder="Username" id="username" required>
<label for="password">
<img src="password.png" alt="PW" style="height:30px; width:30px;">
</label>
<input type="password" name="password" placeholder="Password" id="password" required>
<br><span align="center" style="font-size:small;"><a href="forgotpw.php">Forgot Password</a></span><br>
<input type="submit" value="Login">
</form>
</div></div><div align="center"><img src="images/header.png" alt="Roblox Adopt Me Trading Values">
<ul align="center">
<li><a href="index.php">W/F/L</a></li>
<li><a href="pet-value-list.php">Pet Value List</a></li>
<li><a href="play-games.php">Games</a></li>
<li><a class="active" href="videos.php">Videos</a></li>
<li><a href="tips-to-get-rich.php">Tips</a></li>
<li><a href="roblox-adopt-me.php">About</a></li>
</ul>
</div>
<div class="tradezonevideos">
<div class="outergridvideos">
<div id="google_translate_element" style="text-align:right; display:inline;">
<script type="text/javascript">function googleTranslateElementInit() {  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, gaTrack: true, gaId: 'UA-3744414-1'}, 'google_translate_element');} </script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script></div>
<div style="font-size:24px; font-weight:bold; text-align:center;"><span style="font-size:36px;"><u>Videos</u></span><br>
<script src="https://apis.google.com/js/platform.js"></script>
<div class="g-ytsubscribe" data-channelid="UCW2MNrb1R_c0TW_ekvb5v8A" data-layout="default" data-count="default"></div><br><span style="font-size:small;">Click the button above to subscribe.</span>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Biggest Wins of the Week - June 28 through July 4, 2022</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/8fHz2s6JgVU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Trading a Space Whale on Its First Day</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/9WUw8bl7Jj0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Biggest Wins of the Week - June 20 through June 26, 2022</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/-ytyxFTY3wY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Chick Trading Explosion in Adopt Me!</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/PVMAcJed3m0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">New Feature! Making Your Own Adopt Me Value List</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/PX6htSCzn2M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Trading 4 Mega Neon Pets - May 2022</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/ZDCKojlvdw4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Trading a FR Evil Unicorn (Late April & Early May 2022)</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/VHeaItT5dZQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Biggest Wins of the Week - April 23 through April 29, 2022</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/ZiYWH0rzvd0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Adopt Me Easter Egg Locations in Order - April 2022</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/Kulz0mSjECU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Trading a Neon FR Phoenix (Late Feb & Early March 2022)</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/GidezaBrwlY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Trading a Frost Dragon (Mid-Late January 2022)</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/yhMA0rFSxr8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Trading a Fly Ride Parrot (Early January 2022)</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/k_lRe2AN2qc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Trading a Fly Ride Crow (Late December 2021)</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/kCfUAmYNI1I" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">NEW FEATURE! Find Fair Trades Quickly on AdoptMeTradingValues.com (November 2021)</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/dq1N_-GQtEc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Trading a FR Frost Fury (Late September 2021)</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/CSFs4ufGabs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Trading a FR Arctic Reindeer (September 2021)</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/427wMceOg8A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Trading a Neon FR Unicorn (September 2021)</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/xhm4I7w0Kbo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Making & Trading a Neon FR Turtle (September 2021)</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/RK6v_v8bB8s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Fossil Egg Pet Trading (July 2021)</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/vQSx0nGK6KU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Ocean Egg Pet Trading (June 2021)</span><br><br>

<div id="player"></div>
<script>
      // 2. This code loads the IFrame Player API code asynchronously.
      var tag = document.createElement('script');

      tag.src = "https://www.youtube.com/iframe_api";
      var firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

      // 3. This function creates an <iframe> (and YouTube player)
      //    after the API code downloads.
      var player;
      function onYouTubeIframeAPIReady() {
        player = new YT.Player('player', {
          height: '390',
          width: '640',
          videoId: 'rZHF2MAeJaA',
          playerVars: {
            'playsinline': 1
          },
          events: {
            'onReady': onPlayerReady,
            'onStateChange': onPlayerStateChange
          }
        });
      }

      // 4. The API will call this function when the video player is ready.
      function onPlayerReady(event) {
        //event.target.playVideo();
      }

      // 5. The API calls this function when the player's state changes.
      //    The function indicates that when playing a video (state=1),
      //    the player should play for six seconds and then stop.
      var done = false;
      function onPlayerStateChange(event) {
        if (event.data == YT.PlayerState.PLAYING && !done) {
          //setTimeout(stopVideo, 6000);
          //done = true;
        }
      }
      function stopVideo() {
        player.stopVideo();
      }
	  
	  function seek(mysec){
        if(player){
          player.seekTo(mysec, true);
		 // player.playVideo();
        }
	  }
    </script><br>
<img src="images/138.png" alt="stingray" style="height:50px; width:50px; padding:3px;" onClick="seek(9);"> <img src="images/144.png" alt="crab" style="height:50px; width:50px; padding:3px;" onClick="seek(76);"> <img src="images/142.png" alt="dolphin" style="height:50px; width:50px; padding:3px;" onClick="seek(125);"> <img src="images/140.png" alt="narwhal" style="height:50px; width:50px; padding:3px;" onClick="seek(155);"> <img src="images/143.png" alt="seahorse" style="height:50px; width:50px; padding:3px;" onClick="seek(181);"> <img src="images/137.png" alt="clownfish" style="height:50px; width:50px; padding:3px;" onClick="seek(193);"> <img src="images/141.png" alt="octopus" style="height:50px; width:50px; padding:3px;" onClick="seek(223);"> <img src="images/139.png" alt="shark" style="height:50px; width:50px; padding:3px;" onClick="seek(258);"> <img src="images/145.png" alt="ocean egg" style="height:50px; width:50px; padding:3px;" onClick="seek(315);"><br><br><br>
<hr><br><br>
<span style="margin-left:40px; margin-right:40px; margin-bottom:15px; text-align:center;">Check If Trades Are Fair at AdoptMeTradingValues.com How-To Video</span><br><br>
<iframe width="640" height="390" src="https://www.youtube.com/embed/OrGTadkbX70" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br><br>
</div>
</div>
</div>
<div align="center">

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5814941088162332" crossorigin="anonymous"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5814941088162332" data-ad-slot="7684926393" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<br><br>
<div align="center"><i>Last updated July 7, 2022</i> - <a href="updates.php">View Update Log</a> | <a href="privacypolicy.php">Privacy Policy</a></div><br><br>

<script async src="https://www.googletagmanager.com/gtag/js?id=G-40249HE5LR"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-40249HE5LR');
</script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-60ba7e2fc1d62d27"></script>
</body>
</html>
